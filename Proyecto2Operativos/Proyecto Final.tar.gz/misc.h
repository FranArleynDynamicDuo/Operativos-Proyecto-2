#ifndef MISC_H
#define MISC_H

int RandomBetween(int, int);
int IsNumber(char*);
void Raise(int);
int InArray(int*, int, int);

#endif