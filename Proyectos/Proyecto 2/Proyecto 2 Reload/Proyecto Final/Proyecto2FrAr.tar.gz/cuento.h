#ifndef CORE_H
#define	CORE_H

void MiCuento(Args*);
void Obtenerarchivos(char*, int*, int);

#endif
